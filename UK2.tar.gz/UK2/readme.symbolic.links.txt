drwxrwxr-x.  6 rasp3 rasp3     8192 Apr 16 13:21 .
drwxr-xr-x. 63 rasp3 rasp3     4096 Apr 16 12:48 ..
lrwxrwxrwx.  1 rasp3 rasp3       41 Oct 25  2017 ETAMPNEW_DATA.expanded_rain -> ../RUN.TABLES/ETAMPNEW_DATA.expanded_rain
lrwxrwxrwx.  1 rasp3 rasp3       25 Oct 25  2017 GENPARM.TBL -> ../RUN.TABLES/GENPARM.TBL
-rw-rw-r--.  1 rasp3 rasp3  1337384 Feb  4  2018 geo_em.d01.nc
-rw-rw-r--.  1 rasp3 rasp3 72602528 Feb  4  2018 geo_em.d02.nc
lrwxrwxrwx.  1 rasp3 rasp3       25 Oct 25  2017 GEOGRID.TBL -> ../RUN.TABLES/GEOGRID.TBL
-rwxrwxr-x.  1 rasp3 rasp3   220747 Jun 15  2019 GM.pl
drwxr-x---.  2 rasp3 rasp3        6 Apr 16 13:19 GRIB
drwxrwxr-x.  4 rasp3 rasp3       29 Apr 16 13:19 HTML
lrwxrwxrwx.  1 rasp3 rasp3       25 Oct 25  2017 LANDUSE.TBL -> ../RUN.TABLES/LANDUSE.TBL
drwxrwxr-x.  2 rasp3 rasp3       39 Apr 16 13:19 LOG
lrwxrwxrwx.  1 rasp3 rasp3       25 Oct 25  2017 METGRID.TBL -> ../RUN.TABLES/METGRID.TBL
-rw-rw-r--.  1 rasp3 rasp3     4699 Apr 14 22:52 namelist.input
-rw-rw-r--.  1 rasp3 rasp3     5117 Oct 21  2017 namelist.input.template
-rw-rw-r--.  1 rasp3 rasp3    82916 Apr 14 22:52 namelist.output
-rw-rw-r--.  1 rasp3 rasp3     1049 Apr 14 22:51 namelist.wps
-rw-rw-r--.  1 rasp3 rasp3     1067 Feb  4  2018 namelist.wps.template
drwxrwxr-x.  2 rasp3 rasp3        6 Apr 16 13:19 OUT
-rw-rw-r--.  1 rasp3 rasp3     8389 Apr 14 22:50 rasp.run.parameters.UK2
-rw-rw-r--.  1 rasp3 rasp3     8476 Apr 16 13:19 rasp.run.parameters.UK2+1
-rw-rw-r--.  1 rasp3 rasp3     8389 Oct 21  2017 rasp.run.parameters.UK2.template
lrwxrwxrwx.  1 rasp3 rasp3       23 Oct 25  2017 rasp.site.parameters -> ../rasp.site.parameters
-rw-rw-r--.  1 rasp3 rasp3        2 Apr 16 13:21 readme.symbolic.links.txt
lrwxrwxrwx.  1 rasp3 rasp3       23 Oct 25  2017 RRTM_DATA -> ../RUN.TABLES/RRTM_DATA
lrwxrwxrwx.  1 rasp3 rasp3       12 Oct 25  2017 runGM -> ../bin/runGM
lrwxrwxrwx.  1 rasp3 rasp3       26 Oct 25  2017 SOILPARM.TBL -> ../RUN.TABLES/SOILPARM.TBL
lrwxrwxrwx.  1 rasp3 rasp3       25 Oct 25  2017 VEGPARM.TBL -> ../RUN.TABLES/VEGPARM.TBL
lrwxrwxrwx.  1 rasp3 rasp3       24 Apr 14 22:51 Vtable -> ../RUN.TABLES/Vtable.GFS
lrwxrwxrwx.  1 rasp3 rasp3       16 Oct 25  2017 wrf2gm.ncl -> ../GM/wrf2gm.ncl
-rw-rw-r--.  1 rasp3 rasp3     2222 Oct 21  2017 wrfsi.nl
 
