// run model details for one day only
        { \
            "name": "UKI12", \
            "description": "UK and Ireland 12Km (Coarse)", \
            "enabled": true, \
            "fullname": "UK and EI 12Km (+0)", \
            "url": "http:// ...", \
            "centre":    ["54.1812897", "-5.7709961"],  \
            "swcorner": ["48.5183792", "-14.7452698"], \
            "necorner": ["59.8442001", "3.2032776"],	\
            "resolution": 12000, \
            "zoom": 6, \
            "hours": ["0700", "0800", "0900", "1000", "1100", "1200", "1300", "1400", "1500", "1600", "1700", "1800"], \
            "parameters": ["wstar_bsratio","wstar","bsratio","hwcrit","dwcrit","hbl","dbl","hglider","bltopvariab","experimental1","zwblmaxmin","sfcshf","sfcsunpct","sfctemp","sfcdewpt","mslpress","sfcwind0","sfcwind","blwind","bltopwind","blwindshear","wblmaxmin","zsfclcldif","zsfclcl","zsfclclmask","zblcldif","zblcl","zblclmask","blcwbase","blcloudpct","rain1","cape","blicw","press1000","press950","press850","press700","press500","stars","starshg"], \
			"trackaverage": true, \
            "days": [""] \

// soundings ...
        { "model": "UKI12", \
            "location":[ \
                { "name": "Exeter",          "centre": ["50.7344",   "-3.4139"] }, \
                { "name": "Fairford",        "centre": ["51.682",    "-1.7900"] }, \
                { "name": "Herstmonceaux",   "centre": ["50.8833",   "0.3333"] }, \
                { "name": "Newtown",         "centre": ["52.5157",   "-3.300"] }, \
                { "name": "Cambridge",       "centre": ["52.2050",   "0.1750"] }, \
                { "name": "Nottingham",      "centre": ["52.9667",   "-1.1667"] }, \
                { "name": "Cheviots",        "centre": ["55.5",      "-2.2"] }, \
                { "name": "Callander",       "centre": ["56.2500",   "-4.2333"] }, \
                { "name": "Aboyne",       	 "centre": ["57.0833",   "-2.8333"] }, \
                { "name": "Buckingham",      "centre": ["52.0000",   "-0.9833"] }, \
                { "name": "Larkhill",        "centre": ["51.2000",   "-1.8167"] }, \
                { "name": "Leeds",           "centre": ["53.869",    "-1.650"] }, \
                { "name": "Carrickmore",     "centre": ["54.599",    "-7.049"] }, \
                { "name": "Talgarth",        "centre": ["51.979558", "-3.206081"] }, \
                { "name": "Camphill",        "centre": ["53.305",    "-1.7291"] }, \
                { "name": "Donegal A/P",     "centre": ["55.044201","-8.341000"] }, \
                { "name": "Dublin A/P",      "centre": ["53.421299","-6.270070"] }, \
                { "name": "Galway A/P",      "centre": ["53.300201","-8.941590"] }, \
                { "name": "Kerry A/P",       "centre": ["52.180901","-9.523780"] }, \
                { "name": "Shannon A/P",     "centre": ["52.702000","-8.924820"] }, \
                { "name": "Waterford A/P",   "centre": ["52.199199","-7.086139"] }, \
                { "name": "Tullamore",       "centre": ["53.263294","-7.517395"] } \
                ] \
        } \

